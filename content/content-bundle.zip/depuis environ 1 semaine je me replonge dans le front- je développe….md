# Depuis environ 1 semaine je me replonge dans le front. Je développe…

Depuis environ 1 semaine je me replonge dans le front. Je développe une app react native pour un projet perso. Et pour l'instant, j'adore mon workflow de continuous delivery, le voici : 👇

Par continuous delivery j'entends ici toutes les pratiques et outils me permettant d'être serein et d'avoir une app en permanence dans un état "releasable".

Ce workflo est en constante évolution, mais voici ce que j'ai pour le moment :

Concernant les outils :

⚙️J'utilise bien sûr Expo Pour le développement / build / etc.

⚙️Pour la pipeline de déploiement j'utilise GitHub Action via un "workflow". La pipeline est basique, elle lance les tests et publie sur une release channel expo "staging".

⚙️Pour le feedback des tests j'utilise Jest et Wallaby.js.

⚙️Pour le feedback visuel des composants / screens j'utilise Storybook. Une petite variable de configuration pour le lancer à la place de l'App et le tour est joué.

⚙️Pour le state manager j'utilise rematch, solution dont j'apprécie l'API très simple, et qui embarque redux.

⚙️Pas de backend pour l'instant puisque l'objectif est d'aller vite (et bien, évidemment). J'utilise donc les outils de firebase.

Concernant mon workflow de développement maintenant, voici ce que je fais quand je veux commencer une nouvelle feature :

✅Je rédige un test avec jest, dans une syntaxe similaire à Gherkin. Ce test me sert de test d'acceptation, il est rédigé du point de vue de l'utilisateur (comme 99% de mes tests).

✅Pour les tests d'intégration entre React Native et le core rematch j'utilise testing-library/native

✅Je "test-drive" l'implémentation par petites étapes, j'ajoute des cas de tests en fonction d'exemples concrets, etc. Les rapports de tests générés par Jest peuvent ici servir de "living documentation". Je suis ici dans un contexte d'architecture hexagonale, sans notion de front-end.

✅Pour changer un peu je passe ensuite aux composants "dumb", que je "visual-drive" avec Storybook. J'ai une approche Component-Driven Development. C'est-à-dire que je commence par les composants les plus unitaires et je remonte la hiérarchie comme ça jusqu'au screen.

✅J'écris ensuite des tests d'intégration en partant du "screen" concerné par la feature. C'est dans ce screen que toute la logique est branchée, react-redux, etc. Ces tests me permettent de m'assurer assez sereinement que la fonctionnalité marche bien dans le contexte d'utilisation de l'App. C'est ici aussi que je vais tester la navigation entre écran. En TDD ici aussi.

✅J'ai quelques tests d'intégration pour les secondary adapters (genre mes repository firestore) où j'utilise testcontainers pour tester en isolation, avec une image docker contenant les émulateurs firebase.

✅Enfin, je fais des tests manuels exploratoires pour vérifier que tout est vraiment bien branché, et pour tester ce que je ne peux pas facilement tester de manière automatique (les recaptcha firebase par exemple).

Je reviendrai plus en détails sur chaque point :)

Happy Coding !

✅Je "test-drive" l'implémentation par petites étapes, j'ajoute des cas de tests en fonction d'exemples concrets, etc. Les rapports de tests générés par Jest peuvent ici servir de "living documentation". Je suis ici dans un contexte d'architecture hexagonale, sans notion de front-end.

✅Pour changer un peu je passe ensuite aux composants "dumb", que je "visual-drive" avec Storybook. J'ai une approche Component-Driven Development. C'est-à-dire que je commence par les composants les plus unitaires et je remonte la hiérarchie comme ça jusqu'au screen.

✅J'écris ensuite des tests d'intégration en partant du "screen" concerné par la feature. C'est dans ce screen que toute la logique est branchée, react-redux, etc. Ces tests me permettent de m'assurer assez sereinement que la fonctionnalité marche bien dans le contexte d'utilisation de l'App. C'est ici aussi que je vais tester la navigation entre écran. En TDD ici aussi.

✅J'ai quelques tests d'intégration pour les secondary adapters (genre mes repository firestore) où j'utilise testcontainers pour tester en isolation, avec une image docker contenant les émulateurs firebase.

✅Enfin, je fais des tests manuels exploratoires pour vérifier que tout est vraiment bien branché, et pour tester ce que je ne peux pas facilement tester de manière automatique (les recaptcha firebase par exemple).

Je reviendrai plus en détails sur chaque point :)

Happy Coding !

