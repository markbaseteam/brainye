# Axes d’amélioration :

# 

Axes d’amélioration : 
Rechercher par rapport à des skills / écoles .. 
Ajouter / modifier ses skills depuis là page modifier et la page d’inscription 
Design 
Routage : ne plus afficher id 
Rechercher minuscule 

keiralee@test.fr 
azertyuiop 

Page accueil avec une barre de recherche dans l’annuaire 
Profils des différents utilisateurs 
Page profil présentant ses détails et ses technos 

