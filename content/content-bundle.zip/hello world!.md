# Hello world!

Hello world!

We have a blog that has users, blog posts and blog posts comments. Define the rails models, associations, and tables necessary to model this data. A perfect answer uses Rails conventions

Tables:
users
	id
email
password

posts
        id
        content 
        user_id

comments
	id
	content 
          user_id 
          post_id

post_tags
	id
	post_id 
          Tag_id
tags 
	id
	name

Classes: 
class User
    has_many :posts
    has_many :comments
 End

class Post
     belongs_to :user
     has_many :comments
     has_many :post_tags
     has_many :tags, through: post_tags
end

post./post_tags.first.tag
post.tags.first

class Comment
     belongs_to :user
     belongs_to :post
end
    

class PostTag
     belongs_to :post
     belongs_to :tag
end 

class Tag
    has_many :posts
end

|  def show 	@post = Post.find(params[:id]) end<br/> |
|-----|

Select * from comments where post_id = @post.id

Select * from users where user.id = comment.user_id
/views/posts/show.html.erb

comments
|  <ul> 	<%@post.comments.each do |comment|%> 		comment.user.email      end <ul><br/> |
|-----|

    
belong_to -> a toujours la clé étrangère 

