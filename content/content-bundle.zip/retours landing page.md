# Retours Landing Page 

* ancienne version toujours accessible (/fr) problème de routage 
* Couleur grise pour texte 65 reviews pas lisible 
* Police pas assez lisible 
* Manque alt text sur images / certaines images pas chargée sur chrome 
* Encadre reviews à revoir (plus de padding? Bord arrondis) 

