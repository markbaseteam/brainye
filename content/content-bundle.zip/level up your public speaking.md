# Level up your public speaking

#  **# Level up your public speaking****# 
**
**
**
Chelsea Troy published an article about tech talks and describes why she dislikes most of the presentations out there. And while she’s very snarky in the post, Chelsea gives some excellent advice on how to give an engaging talk! 💯

