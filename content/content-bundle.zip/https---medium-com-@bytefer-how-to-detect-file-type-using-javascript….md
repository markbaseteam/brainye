# https://medium.com/@bytefer/how-to-detect-file-type-using-javascript…

https://medium.com/@bytefer/how-to-detect-file-type-using-javascript-251f67679035?source=email-612f9f2ac415-1659744731771-digest.reader-8c0f5ca1523c-251f67679035----0-98------------------b923ca57_8714_4970_925c_58179af8a812-1

https://medium.com/@kartikpatel_97737/how-to-write-less-code-in-javascript-1213399321b0

