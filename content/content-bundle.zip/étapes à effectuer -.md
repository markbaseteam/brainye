# Étapes à effectuer :



Étapes à effectuer : 

1. Verifier le code push 
2. Supprimer repo (local)
3. Cloner repo à nouveau 
4. Debug en local branché sur dev

Principe : 
API Bankin doit faire appel vers prédiction (dans fonction startAnalysis) et récupérer le résultat

Notes : 

Premier version où on récupère result, on le stock, on ajoute dans chaque analyse de groupe le résultat de prédiction correspondant

si possible v2, pour chaque groupe de transaction faire une prédiction correspondante (uuid groupe de transactions en entrée, résultat en sortie)
query params en plus si pas là garder v1 

