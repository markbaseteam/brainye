# Des points importants jusqu'ici :

Des points importants jusqu'ici :
- savoir ce que sont les tests unitaires, d'integration et e2e et leur utilité
 
- savoir installer et lancer un outil de test automatisé
 
- pouvoir écrire les différent type de tests
 
- maitriser les notions de     block de tests (fichier, describe, it, test, etc..)     de hook (beforeAll, etc..)     de résultat attendu (expect) et les methodes de matching associées     de mock (maitrise du contexte et des interactions autour du block de code)     de coverage

