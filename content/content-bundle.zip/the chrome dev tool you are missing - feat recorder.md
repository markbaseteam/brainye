# The Chrome Dev Tool you are missing : FEAT Recorder
[https://medium.com/weekly-webtips/the-chrome-dev-tool-you-are-missing-feat-recorder-341a7388973](https://medium.com/weekly-webtips/the-chrome-dev-tool-you-are-missing-feat-recorder-341a7388973)

