# Best SWE RESSOURCES 
[https://vm.tiktok.com/ZMF1tcGNb/](https://vm.tiktok.com/ZMF1tcGNb/)

Visualgo.net 

